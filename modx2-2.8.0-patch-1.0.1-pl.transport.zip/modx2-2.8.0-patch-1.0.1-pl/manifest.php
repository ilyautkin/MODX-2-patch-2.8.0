<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '7e5f8b426fcb69aadf739cc5b18b5ad1',
      'native_key' => NULL,
      'filename' => 'modCategory/372bca54ba5d709bc06719e443ccb926.vehicle',
    ),
  ),
);
<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'dbb0f9e9b067662e5b7a03f78237e664',
      'native_key' => NULL,
      'filename' => 'modCategory/ef0df67587acd77c7b9838da9b007a54.vehicle',
    ),
  ),
);
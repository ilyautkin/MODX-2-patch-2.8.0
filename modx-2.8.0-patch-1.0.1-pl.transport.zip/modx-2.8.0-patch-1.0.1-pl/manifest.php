<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'e7969700bd2d236167f70cb3fc9403f9',
      'native_key' => NULL,
      'filename' => 'modCategory/abfbd291d580770ed9b40bda6d62f7dd.vehicle',
    ),
  ),
);